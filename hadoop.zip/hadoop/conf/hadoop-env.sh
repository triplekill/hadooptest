# Set Hadoop-specific environment variables here.

# The only required environment variable is JAVA_HOME.  All others are
# optional.  When running a distributed configuration it is best to
# set JAVA_HOME in this file, so that it is correctly defined on
# remote nodes.

# The java implementation to use.  Required.
export JAVA_HOME=/usr

# Extra Java CLASSPATH elements.  Optional.
# export HADOOP_CLASSPATH=

# Extra Java runtime options.  Empty by default.
export HADOOP_MASTER_OPTS="-XX:GCTimeRatio=10 -XX:+UseConcMarkSweepGC -XX:+UseParNewGC -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=0 -XX:+CMSClassUnloadingEnabled -XX:-CMSParallelRemarkEnabled -XX:CMSInitiatingOccupancyFraction=70 -XX:SoftRefLRUPolicyMSPerMB=0 -XX:MaxTenuringThreshold=7 -Dcom.sun.management.jmxremote"

export HADOOP_SLAVE_OPTS="-XX:GCTimeRatio=10 -XX:+UseParallelGC -XX:ParallelGCThreads=4 -XX:+UseParallelOldGC -XX:YoungGenerationSizeIncrement=20 -XX:TenuredGenerationSizeIncrement=20 -XX:AdaptiveSizeDecrementScaleFactor=2 -Dcom.sun.management.jmxremote"
# Command specific options appended to HADOOP_OPTS when specified

# MAX heap size MUST be modified according to cluster environment
export HADOOP_NAMENODE_OPTS="-Xmx10000m $HADOOP_MASTER_OPTS"
export HADOOP_SECONDARYNAMENODE_OPTS="-Xmx10000m $HADOOP_MASTER_OPTS"
export HADOOP_JOBTRACKER_OPTS="-Xmx10000m $HADOOP_MASTER_OPTS $HADOOP_JOBTRACKER_OPTS"
export HADOOP_DATANODE_OPTS="-Xmx3000m $HADOOP_SLAVE_OPTS"
export HADOOP_TASKTRACKER_OPTS="-Xmx1000m -XX:OnOutOfMemoryError=\"$HADOOP_HOME/bin/stop-tasktracker.sh;$HADOOP_HOME/bin/start-tasktracker.sh\" $HADOOP_SLAVE_OPTS"
export HADOOP_BALANCER_OPTS="-Xmx1024m $HADOOP_SLAVE_OPTS"
export HADOOP_RAIDNODE_OPTS=$HADOOP_DATANODE_OPTS
export HADOOP_JOBHISTORYSERVER_OPTS="-Xmx1024m $HADOOP_SLAVE_OPTS $HADOOP_JOBHISTORYSERVER_OPTS"

# specify HADOOP_CLIENT  MAX heap size, used for common operation like fs, dfs, fsck..
export HADOOP_CLIENT_OPTS="-Xmx3000m"
export HADOOP_COMPRESSOR_OPTS="-Xmx1024m"
# Extra ssh options.  Empty by default.
# export HADOOP_SSH_OPTS="-o ConnectTimeout=1 -o SendEnv=HADOOP_CONF_DIR"

# Where log files are stored.  $HADOOP_HOME/logs by default.
export HADOOP_LOG_DIR=${HADOOP_HOME}/logs

export CUSTOMIZE_LIBRARY_PATH=""
# File naming remote slave hosts.  $HADOOP_HOME/conf/slaves by default.
# export HADOOP_SLAVES=${HADOOP_HOME}/conf/slaves

# host:path where hadoop code should be rsync'd from.  Unset by default.
# export HADOOP_MASTER=master:/home/$USER/src/hadoop

# Seconds to sleep between slave commands.  Unset by default.  This
# can be useful in large clusters, where, e.g., slave rsyncs can
# otherwise arrive faster than the master can service them.
# export HADOOP_SLAVE_SLEEP=0.1

# The directory where pid files are stored. /tmp by default.
export HADOOP_PID_DIR=${HADOOP_HOME}/pids

# A string representing this instance of hadoop. $USER by default.
# export HADOOP_IDENT_STRING=$USER

# The scheduling priority for daemon processes.  See 'man nice'.
# export HADOOP_NICENESS=10
